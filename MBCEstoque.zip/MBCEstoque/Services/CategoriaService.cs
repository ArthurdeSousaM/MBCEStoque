using MBCEstoque.Data;
using MBCEstoque.Models;
using MBCEstoque.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace MBCEstoque.Services
{
    public class CategoriaService : ICategoriaService
    {
        private readonly SQLServerEstoqueDbContext _context;

        public CategoriaService(SQLServerEstoqueDbContext context)
        {
            _context = context;
        }

        public async Task<List<Categoria>> ListarTodasCategorias()
        {
            return await _context.Categorias.AsNoTracking().ToListAsync();
        }

        public async Task<Categoria?> PesquisarCategoriaPorId(int id)
        {
            return await _context.Categorias
                .AsNoTracking()
                .FirstOrDefaultAsync(c => c.Id == id);
        }

        public async Task<Categoria> CriarAsync(Categoria categoria)
        {
            _context.Categorias.Add(categoria);
            await _context.SaveChangesAsync();
            return categoria;
        }

        public async Task<Categoria> AlterarAsync(Categoria categoria)
        {
            _context.ChangeTracker.Clear();
            _context.Categorias.Update(categoria);
            await _context.SaveChangesAsync();
            return categoria;
        }

        public async Task<bool> ExcluirAsync(int id)
        {
            var categoria = await _context.Categorias.FindAsync(id);
            if (categoria is null) return false;

            _context.Categorias.Remove(categoria);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}

