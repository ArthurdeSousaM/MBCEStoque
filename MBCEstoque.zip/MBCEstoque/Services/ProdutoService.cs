using MBCEstoque.Data;
using MBCEstoque.Models;
using MBCEstoque.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace MBCEstoque.Services
{
    public class ProdutoService : IProdutoService
    {
        private readonly SQLServerEstoqueDbContext _context;

        public ProdutoService(SQLServerEstoqueDbContext context)
        {
            _context = context;
        }

        public async Task<List<Produto>> ListarTodosProdutos()
        {
            return await _context.Produtos
                .Include(p => p.Categoria)
                .Include(p => p.Fornecedor)
                .AsNoTracking()
                .ToListAsync();
        }

        public async Task<Produto?> PesquisarProdutoPorId(int id)
        {
            return await _context.Produtos
                .Include(p => p.Categoria)
                .Include(p => p.Fornecedor)
                .AsNoTracking()
                .FirstOrDefaultAsync(p => p.Id == id);
        }

        public async Task<Produto> CriarAsync(Produto produto)
        {
            _context.Produtos.Add(produto);
            await _context.SaveChangesAsync();
            return produto;
        }

        public async Task<Produto> AlterarAsync(Produto produto)
        {
            _context.ChangeTracker.Clear();
            _context.Produtos.Update(produto);
            await _context.SaveChangesAsync();
            return produto;
        }

        public async Task<bool> ExcluirAsync(int id)
        {
            var produto = await _context.Produtos.FindAsync(id);
            if (produto is null) return false;

            _context.Produtos.Remove(produto);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}

