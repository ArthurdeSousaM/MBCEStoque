﻿using MBCEstoque.Models;

namespace MBCEstoque.Services.Interfaces
{
    public interface IFornecedorService
    {
        Task<List<Fornecedor>> ListarTodosFornecedores();
        Task<Fornecedor?> PesquisarFornecedorPorId(int id);
        Task<Fornecedor> CriarAsync(Fornecedor fornecedor);
        Task<bool> AlterarAsync(Fornecedor fornecedor);
        Task<bool> ExcluirAsync(int id);
    }
}
