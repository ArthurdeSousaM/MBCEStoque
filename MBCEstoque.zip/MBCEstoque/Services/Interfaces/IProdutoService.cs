using MBCEstoque.Models;

namespace MBCEstoque.Services.Interfaces
{
    public interface IProdutoService
    {
        Task<List<Produto>> ListarTodosProdutos();
        Task<Produto?> PesquisarProdutoPorId(int id);
        Task<Produto> CriarAsync(Produto produto);
        Task<Produto> AlterarAsync(Produto produto);
        Task<bool> ExcluirAsync(int id);
    }
}
