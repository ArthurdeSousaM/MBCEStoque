﻿namespace MBCEstoque.Models.Enum
{
    public enum TipoMovimentacao
    {
        Entrada = 1,
        Saida = 2,
    }
}
