﻿using MBCEstoque.Models;
using Microsoft.EntityFrameworkCore;

namespace MBCEstoque.Data
{
    public class SQLServerEstoqueDbContext : DbContext
    {
        public SQLServerEstoqueDbContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<Produto> Produtos { get; set; }
        public DbSet<Categoria> Categorias { get; set; }
        public DbSet<Fornecedor> Fornecedores { get; set; }
        public DbSet<Estoque> Estoques { get; set; }
        public DbSet<MovimentacaoEstoque> Movimentacoes { get; set; }
        //DEvemos retornar daqui, não foi terminado
        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            // ── Nomes das tabelas ────────────────────────────────────
            builder.Entity<Produto>().ToTable("Produto");
            builder.Entity<Categoria>().ToTable("Categoria");
            builder.Entity<Fornecedor>().ToTable("Fornecedor");
            builder.Entity<Estoque>().ToTable("Estoque");
            builder.Entity<MovimentacaoEstoque>().ToTable("MovimentacoesEstoque");

            // ── FK: Produto N:1 Categoria ────────────────────────────
            // Muitos produtos pertencem a uma categoria.
            // Restrict: impede deletar categoria que ainda tem produtos.
            builder.Entity<Produto>()
                .HasOne(p => p.Categoria)
                .WithMany(c => c.Produtos)
                .HasForeignKey(p => p.CategoriaId)
                .OnDelete(DeleteBehavior.Restrict);

            // ── FK: Produto N:1 Fornecedor ───────────────────────────
            // Muitos produtos pertencem a um fornecedor.
            // Restrict: impede deletar fornecedor que ainda tem produtos.
            builder.Entity<Produto>()
                .HasOne(p => p.Fornecedor)
                .WithMany(f => f.Produtos)
                .HasForeignKey(p => p.FornecedorId)
                .OnDelete(DeleteBehavior.Restrict);

            // ── FK: Estoque 1:1 Produto ──────────────────────────────
            // Cada produto tem exatamente um registro de estoque.
            // Cascade: deletar produto apaga o estoque vinculado.
            builder.Entity<Produto>()
                .HasOne(p => p.Estoque)
                .WithOne(e => e.Produto)
                .HasForeignKey<Estoque>(e => e.ProdutoId)
                .OnDelete(DeleteBehavior.Cascade);

            // UNIQUE INDEX garante a cardinalidade 1:1 no banco
            builder.Entity<Estoque>()
                .HasIndex(e => e.ProdutoId)
                .IsUnique()
                .HasDatabaseName("UQ_Estoque_ProdutoId");

            // ── FK: MovimentacaoEstoque N:1 Produto ──────────────────
            // Um produto pode ter muitas movimentações.
            // Restrict: não apaga histórico se produto for deletado.
            builder.Entity<MovimentacaoEstoque>()
                .HasOne(m => m.Produto)
                .WithMany(p => p.Movimentacoes)
                .HasForeignKey(m => m.ProdutoId)
                .OnDelete(DeleteBehavior.Restrict);

            // ── Enum → TINYINT ───────────────────────────────────────
            // 0 = Entrada | 1 = Saída
            builder.Entity<MovimentacaoEstoque>()
                .Property(m => m.TipoMovimentacao)
                .HasConversion<byte>();

            // ── Índices de performance ───────────────────────────────
            builder.Entity<Produto>()
                .HasIndex(p => p.Nome)
                .HasDatabaseName("IX_Produtos_Nome");

            builder.Entity<Produto>()
                .HasIndex(p => p.CodigoBarras)
                .IsUnique()
                .HasFilter("[CodigoBarras] IS NOT NULL")
                .HasDatabaseName("IX_Produtos_CodigoBarras");

            builder.Entity<Produto>()
                .HasIndex(p => p.CategoriaId)
                .HasDatabaseName("IX_Produtos_CategoriaId");

            builder.Entity<Produto>()
                .HasIndex(p => p.FornecedorId)
                .HasDatabaseName("IX_Produtos_FornecedorId");

            builder.Entity<MovimentacaoEstoque>()
                .HasIndex(m => new { m.ProdutoId, m.DataMovimentacao })
                .HasDatabaseName("IX_Mov_Produto_Data");

            // ── Seed data ────────────────────────────────────────────
            builder.Entity<Categoria>().HasData(
                new Categoria { Id = 1, Nome = "Eletrônicos", Descricao = null, Ativo = true },
                new Categoria { Id = 2, Nome = "Informática", Descricao = null, Ativo = true },
                new Categoria { Id = 3, Nome = "Escritório", Descricao = null, Ativo = true }
            );
        }

    }
}